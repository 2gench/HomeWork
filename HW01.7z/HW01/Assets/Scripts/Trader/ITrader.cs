public interface ITrader
{
    void Trade();
}
