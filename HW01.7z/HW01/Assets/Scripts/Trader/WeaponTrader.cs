using UnityEngine;

public class WeaponTrader : ITrader
{
    public void Trade()
    {
        Debug.Log("Now I can sell you a weapon!");
    }
}
