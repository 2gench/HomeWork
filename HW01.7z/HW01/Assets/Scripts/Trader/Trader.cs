using UnityEngine;

public class Trader : MonoBehaviour
{
    [SerializeField] private Player _player;
    private ITrader _trader;

    private bool _isTrading = false;


    private void Update()
    {
        int playerReputation = _player.GetReputation();

        TradingWithPlayer(playerReputation);
    }

    private void TradingWithPlayer(int reputation)
    {
        if (!_isTrading)
        {
            return;
        }

        if (_isTrading)
        {
            if (reputation < 20)
            {
                _trader = new NotTradingTrader();
                _trader.Trade();
            }
            else if (reputation <= 50)
            {
                _trader = new FruitTrader();
                _trader.Trade();
            }
            else
            {
                _trader = new WeaponTrader();
                _trader.Trade();
            }
        }
    }


    private void OnTriggerEnter(Collider other)
    {
        _isTrading = true;

        Debug.Log("Hi " + other.transform.parent.name + "! " + "You are in trading zone.");
    }

    private void OnTriggerExit(Collider other)
    {
        _isTrading = false;

        Debug.Log("You are leaving trading zone.");
    }

    private void OnDrawGizmos()
    {
        Color transparentGreen = new Color(0f, 1f, 0f, 0.3f);
        Gizmos.color = transparentGreen;
        Gizmos.DrawCube(transform.position, new Vector3(4, 1, 4));
    }
}
