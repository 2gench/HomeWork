using UnityEngine;

public class NotTradingTrader : ITrader
{
    public void Trade()
    {
        Debug.Log("I don't trade with you. Get to at least 20 reputation.");
    }
}
