using UnityEngine;

[SelectionBase]
public class Player : MonoBehaviour
{
    [SerializeField, Range(0, 100)] private int _reputation = 0;

    public int GetReputation()
    {
        return _reputation;
    }
}
