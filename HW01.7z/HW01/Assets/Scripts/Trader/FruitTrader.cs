using UnityEngine;

public class FruitTrader : ITrader
{
    public void Trade()
    {
        Debug.Log("I only sell fruit.");
    }
}
