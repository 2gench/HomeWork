using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField, Min(1f)] private float _speed = 10f;
    [SerializeField] private float _lifeTime = 3f;
   
    private void Update()
    {
        transform.Translate(Vector3.forward * _speed * Time.deltaTime);   
        Destroy(gameObject, _lifeTime);
    }
}
