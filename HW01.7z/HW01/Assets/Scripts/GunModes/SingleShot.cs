using UnityEngine;

public class SingleShot : FiringMode
{
    public SingleShot(MonoBehaviour monoBehaviour, Transform projectilePrefab, Transform firePoint, int ammoClip) 
        : base(monoBehaviour, projectilePrefab, firePoint, ammoClip) { }

    public override void Fire()
    {
        if (_ammoClip > 0)
        {
            Object.Instantiate(_projectilePrefab, _firePoint.position, _firePoint.rotation);
            _ammoClip--;
        }
        else
        {
            Debug.LogWarning("No ammo!");
        }
    }
}
