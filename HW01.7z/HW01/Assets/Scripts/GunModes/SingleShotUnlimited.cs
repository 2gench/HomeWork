using UnityEngine;

public class UnlimitedSingleShot : FiringMode
{
    public UnlimitedSingleShot(MonoBehaviour monoBehaviour, Transform projectilePrefab, Transform firePoint) 
        : base(monoBehaviour, projectilePrefab, firePoint, int.MaxValue) { }

    public override void Fire()
    {
        Object.Instantiate(_projectilePrefab, _firePoint.position, _firePoint.rotation);
    }
}
