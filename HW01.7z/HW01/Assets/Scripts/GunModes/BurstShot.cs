using System.Collections;
using UnityEngine;

public class BurstShot : FiringMode
{
    public BurstShot(MonoBehaviour monoBehaviour, Transform projectilePrefab, Transform firePoint, int ammoClip) 
        : base(monoBehaviour, projectilePrefab, firePoint, ammoClip) { }

    public override void Fire()
    {
        if (_ammoClip > 0)
        {
            _monoBehaviour.StartCoroutine(BurstFire());
        }
        else
        {
            Debug.LogWarning("No ammo!");
        }
    }

    private IEnumerator BurstFire()
    {
        int _burstCount = 3;

        while (_burstCount > 0 && _ammoClip > 0) 
        {
            Object.Instantiate(_projectilePrefab, _firePoint.position, _firePoint.rotation);
            _ammoClip--;
            _burstCount--;

            float _burstDelay = Random.Range(.02f, .08f);
            yield return new WaitForSeconds(_burstDelay);
        }
    }
}
