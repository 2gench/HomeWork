using UnityEngine;

public class Gun : MonoBehaviour
{
    public Transform _projectilePrefab;
    public Transform _firePoint;

    [SerializeField] private int _ammoClip = 10;
    private float _fireRate = .25f;
    private float _nextFireTime = 0;

    private FiringMode _firingMode;

    void Start()
    {
        Debug.Log("Use keys 1 2 3 to switch firing modes.");
        SetFiringMode(new SingleShot(this, _projectilePrefab, _firePoint, _ammoClip));
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && Time.time >= _nextFireTime)
        {
            _firingMode.Fire();
            _nextFireTime = Time.time + _fireRate;
        }

        if (Input.GetKeyDown(KeyCode.Alpha1))
            SetFiringMode(new SingleShot(this, _projectilePrefab, _firePoint, _ammoClip));

        if (Input.GetKeyDown(KeyCode.Alpha2))
            SetFiringMode(new UnlimitedSingleShot(this, _projectilePrefab, _firePoint));

        if (Input.GetKeyDown(KeyCode.Alpha3))
            SetFiringMode(new BurstShot(this, _projectilePrefab, _firePoint, _ammoClip));
    }

    private void SetFiringMode(FiringMode _selectedMode)
    {
        _firingMode = _selectedMode;
        Debug.Log("Firing mode set to: " + _firingMode.GetType().Name);
    }
}

