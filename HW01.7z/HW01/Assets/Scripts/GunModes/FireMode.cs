using UnityEngine;

public abstract class FiringMode
{
    protected Transform _projectilePrefab;
    protected Transform _firePoint;
    protected int _ammoClip;
    protected MonoBehaviour _monoBehaviour;

    public FiringMode(MonoBehaviour monoBehaviour, Transform projectilePrefab, Transform firePoint, int ammoClip)
    {
        _monoBehaviour = monoBehaviour;
        _projectilePrefab = projectilePrefab;
        _firePoint = firePoint;
        _ammoClip = ammoClip;
    }

    public abstract void Fire();
}
